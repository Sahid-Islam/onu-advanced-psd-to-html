// ===========================
// navbar
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0px";
  } else {
    document.getElementById("navbar").style.top = "-90px";
  }
  prevScrollpos = currentScrollPos;
}
// ==================
$(".owl-carousel").on("initialized.owl.carousel", () => {
  setTimeout(() => {
    $(".owl-item.active .owl-slide-animated").addClass("is-transitioned");
    $("section").show();
  }, 200);
});

const $owlCarousel = $(".owl-carousel").owlCarousel({
  items: 1,
  loop: true,
  autoplay:true,
  nav: true,
  dots:true,
  autoplayTimeout:2000,
  navText: [] });



$owlCarousel.on("changed.owl.carousel", e => {
  $(".owl-slide-animated").removeClass("is-transitioned");

  const $currentOwlItem = $(".owl-item").eq(e.item.index);
  $currentOwlItem.find(".owl-slide-animated").addClass("is-transitioned");

  const $target = $currentOwlItem.find(".owl-slide-text");
  doDotsCalculations($target);
});

$owlCarousel.on("resize.owl.carousel", () => {
  setTimeout(() => {
    setOwlDotsPosition();
  }, 50);
});



setOwlDotsPosition();

function setOwlDotsPosition() {
  const $target = $(".owl-item.active .owl-slide-text");
  doDotsCalculations($target);
}

function doDotsCalculations(el) {
  const height = el.height();
  const { top, left } = el.position();
  const res = height + top + 20;

  $(".owl-carousel .owl-dots").css({
    top: `${res}px`,
    left: `${left}px` });

}

// protfolio
// =======================================
//init

// isotop
var $grid = $('.grid').isotope({
  itemSelector:'.item',
  layoutMode:'fitRows',
    getSortData: {
    color: '[data-color]',
    number: '.number',
    number1:'.number1',
    number2:'.number2',
    number3:'.number3',
    number4:'.number4'
  },
  // sort by color then number
  sortBy: [ 'number', 'color','number1','number2','number3','number4' ]
});


// sort items on button click
$('.sort-by-button-group').on( 'click', 'button', function() {
  var sortValue = $(this).attr('data-sort-value');
  sortValue = sortValue.split(',');
  $grid.isotope({ sortBy: sortValue });
});

$('.button-group').each(function(i,buttonGroup){
  var $buttonGroup = $(buttonGroup);
  $buttonGroup.on('click','button',function(){
  $buttonGroup.find('.is-checked').removeClass('is-checked');
  $(this).addClass('is-checked');
});
});


// isotop













// end portfolio
// ============================================

// $('.owl-carousel').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:true,
//     autoplay:false,
//     dots:true,
//     autoplayTimeout:2000,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:3
//         },
//         1000:{
//             items:5
//         }
//     }
// });

// function createQuote(quote,callback){
// 	var myQuote = "I like it, " + quote;
// 	callback(myQuote);
// }
// function logQuote(quote){
// 	console.log(quote);
// }
// createQuote("Eat vegetable", logQuote);




